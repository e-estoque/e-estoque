package com.estoque.api;

import com.estoque.model.Endereco;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Consulta o endereço a partir de um CEP usando a API pública ViaCEP
public class ViaCepClient {

    private static final String BASE_URL  = "https://viacep.com.br/ws/%s/json/";
    private static final int TIMEOUT_MS   = 8000;

    public Endereco buscarEndereco(String cep) throws IOException {
        // Remove tudo que não for dígito
        String cepLimpo = cep.replaceAll("\\D", "");

        if (cepLimpo.length() != 8) {
            throw new IllegalArgumentException(
                    "CEP deve ter 8 dígitos numéricos. Recebido: " + cep);
        }

        String urlStr = String.format(BASE_URL, cepLimpo);
        HttpURLConnection conn = null;

        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(TIMEOUT_MS);
            conn.setReadTimeout(TIMEOUT_MS);
            conn.setRequestProperty("Accept", "application/json");

            int httpStatus = conn.getResponseCode();
            if (httpStatus != HttpURLConnection.HTTP_OK) {
                throw new IOException("ViaCEP retornou status HTTP " + httpStatus + " para o CEP " + cep);
            }

            StringBuilder sb = new StringBuilder();
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
            String linha;
            while ((linha = reader.readLine()) != null) {
                sb.append(linha);
            }
            reader.close();

            String json = sb.toString();

            // ViaCEP retorna {"erro": true} para CEPs inexistentes
            if (json.contains("\"erro\"")) {
                return null;
            }

            return montarEndereco(json, cepLimpo);

        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    private Endereco montarEndereco(String json, String cepLimpo) {
        Endereco end = new Endereco();
        end.setCep(cepLimpo.substring(0, 5) + "-" + cepLimpo.substring(5));
        end.setLogradouro(extrairCampo(json, "logradouro"));
        end.setComplemento(extrairCampo(json, "complemento"));
        end.setBairro(extrairCampo(json, "bairro"));
        end.setCidade(extrairCampo(json, "localidade"));
        end.setUf(extrairCampo(json, "uf"));
        return end;
    }

    // Extrai o valor de um campo do JSON simples retornado pela API
    private String extrairCampo(String json, String campo) {
        Pattern p = Pattern.compile("\"" + campo + "\"\\s*:\\s*\"([^\"]*?)\"");
        Matcher m = p.matcher(json);
        if (m.find()) {
            String valor = m.group(1).trim();
            return valor.isEmpty() ? null : valor;
        }
        return null;
    }
}
